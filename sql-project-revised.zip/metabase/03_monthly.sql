WITH params AS (
SELECT 1::integer AS company_id,
       TIMESTAMP '2021-07-01' AS start_at,
       TIMESTAMP '2022-05-01' AS end_at
),
cu AS (
SELECT u.id, u.date_joined
FROM users u CROSS JOIN params p
WHERE u.company_id = p.company_id AND u.date_joined < p.end_at
),
runs AS (
SELECT r.id, r.user_id, r.problem_id, r.created_at
FROM coderun r JOIN cu u ON u.id = r.user_id CROSS JOIN params p
WHERE r.created_at >= u.date_joined AND r.created_at < p.end_at
),
submits AS (
SELECT s.id, s.user_id, s.problem_id, s.created_at, s.is_false
FROM codesubmit s JOIN cu u ON u.id = s.user_id CROSS JOIN params p
WHERE s.created_at >= u.date_joined AND s.created_at < p.end_at
),
visits AS (
SELECT e.id, e.user_id, e.entry_at
FROM userentry e JOIN cu u ON u.id = e.user_id CROSS JOIN params p
WHERE e.entry_at >= u.date_joined AND e.entry_at < p.end_at
),
first_success AS (
SELECT DISTINCT ON (user_id, problem_id)
       user_id, problem_id, created_at AS solved_at, id AS submit_id
FROM submits
WHERE is_false = 0
ORDER BY user_id, problem_id, created_at, id
),
homework AS (
SELECT DISTINCT pc.problem_id
FROM problem_to_company pc CROSS JOIN params p
WHERE pc.company_id = p.company_id
),
practice AS (
SELECT user_id, problem_id, created_at FROM runs
UNION
SELECT user_id, problem_id, created_at FROM submits
),
months AS (
    SELECT generate_series(date_trunc('month', start_at),
           end_at - INTERVAL '1 month', INTERVAL '1 month') AS month FROM params
)
SELECT m.month::date,
       (SELECT count(*) FROM cu WHERE date_joined < m.month + INTERVAL '1 month') AS students_to_date,
       (SELECT count(DISTINCT user_id) FROM visits WHERE entry_at >= m.month AND entry_at < m.month + INTERVAL '1 month') AS visitors,
       (SELECT count(DISTINCT user_id) FROM practice WHERE created_at >= m.month AND created_at < m.month + INTERVAL '1 month') AS active_students,
       (SELECT count(*) FROM runs WHERE created_at >= m.month AND created_at < m.month + INTERVAL '1 month') AS runs,
       (SELECT count(*) FROM submits WHERE created_at >= m.month AND created_at < m.month + INTERVAL '1 month') AS submissions,
       (SELECT count(*) FROM first_success WHERE solved_at >= m.month AND solved_at < m.month + INTERVAL '1 month') AS new_solutions
FROM months m ORDER BY m.month;