-- PostgreSQL. Запустить один раз в текущем сеансе перед запросами 01–12.
-- Временные представления не изменяют исходные таблицы.
CREATE TEMP VIEW params AS
SELECT 1::integer AS company_id,
       TIMESTAMP '2021-07-01' AS start_at,
       TIMESTAMP '2022-05-01' AS end_at;

CREATE TEMP VIEW cu AS
SELECT u.id, u.date_joined
FROM users u CROSS JOIN params p
WHERE u.company_id = p.company_id AND u.date_joined < p.end_at;

-- События до регистрации не считаем учебной активностью.
-- Их число отдельно проверяется в 01_quality.sql.
CREATE TEMP VIEW runs AS
SELECT r.id, r.user_id, r.problem_id, r.created_at
FROM coderun r JOIN cu u ON u.id = r.user_id CROSS JOIN params p
WHERE r.created_at >= u.date_joined AND r.created_at < p.end_at;

CREATE TEMP VIEW submits AS
SELECT s.id, s.user_id, s.problem_id, s.created_at, s.is_false
FROM codesubmit s JOIN cu u ON u.id = s.user_id CROSS JOIN params p
WHERE s.created_at >= u.date_joined AND s.created_at < p.end_at;

CREATE TEMP VIEW visits AS
SELECT e.id, e.user_id, e.entry_at
FROM userentry e JOIN cu u ON u.id = e.user_id CROSS JOIN params p
WHERE e.entry_at >= u.date_joined AND e.entry_at < p.end_at;

-- Первая успешная сдача за ВСЮ доступную историю до конца периода.
-- id разрешает совпадения временных меток.
CREATE TEMP VIEW first_success AS
SELECT DISTINCT ON (user_id, problem_id)
       user_id, problem_id, created_at AS solved_at, id AS submit_id
FROM submits
WHERE is_false = 0
ORDER BY user_id, problem_id, created_at, id;

CREATE TEMP VIEW homework AS
SELECT DISTINCT pc.problem_id
FROM problem_to_company pc CROSS JOIN params p
WHERE pc.company_id = p.company_id;

CREATE TEMP VIEW practice AS
SELECT user_id, problem_id, created_at FROM runs
UNION
SELECT user_id, problem_id, created_at FROM submits;
